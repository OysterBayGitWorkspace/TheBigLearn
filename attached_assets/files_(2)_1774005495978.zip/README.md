# ⚡ TERMSHEET DOJO

**Master German VC Deal Terms — one question at a time.**

A gamified learning app for venture capital terminology, focused on the German/DACH market. Built with React + Vite.

---

## 🚀 Deploy on Replit (Step by Step)

### Option A: Fresh React Repl (Recommended)

1. Go to [replit.com](https://replit.com) → Click **"+ Create Repl"**
2. Choose **"React (Vite)"** as the template
3. Name it `termsheet-dojo` → Click **Create**
4. Replit will generate default files. **Delete everything** inside the `src/` folder
5. **Move these files** into the ROOT of your Repl (not inside `src/`):

```
termsheet-dojo/
├── index.html       ← replace the existing one
├── main.jsx         ← put at root level
├── App.jsx          ← put at root level (the big one)
├── package.json     ← replace the existing one
└── vite.config.js   ← replace the existing one
```

6. Delete the now-empty `src/` folder
7. Click the green **Run** button
8. Wait ~15 seconds — the app will appear in the preview panel

### Option B: Blank Node.js Repl

1. Create a **"Blank (Node.js)"** Repl
2. Upload all 5 files to the root directory
3. In the Shell, run: `npm install && npm run dev`
4. The app will start on port 5173

### Troubleshooting

- **"Module not found"** → Make sure `App.jsx` and `main.jsx` are at the ROOT level, not inside `src/`
- **Dependencies error** → Open Shell tab, run `npm install`
- **Blank screen** → Check browser console (F12). Usually a file path issue
- **Slow first load** → Normal, Vite needs to bundle on first run

---

## 📖 What's Inside

### Resource Library
30+ curated resources across 4 categories — from Venture Deals to Weitnauer's Praxishandbuch and BAND/GESSI templates.

### Training Engine
40+ scenario-based questions across 9 categories:
- Liquidation Preferences (participating, non-participating, stacking)
- Anti-Dilution (full ratchet, weighted average, narrow vs broad)
- ESOP & VSOP (virtual shares, vesting, §19a EStG tax treatment)
- Exit & Transfer Rights (ROFR, Tag-Along, Drag-Along)
- Convertible Instruments (Wandeldarlehen vs SAFE)
- Governance & Control (Gesellschafterversammlung, Beirat)
- Valuation & Economics (option pool shuffle, waterfall analysis)
- Pre-emption & Pro-rata
- Advanced Scenarios (multi-mechanic, cascading effects)

### Game Mechanics
- **6 Levels**: Intern → Analyst → Associate → Principal → Partner → Managing Partner
- **XP System**: Difficulty bonuses, speed bonuses, combo multipliers, 2× boosts
- **12 Achievements**: Unlockable sticker collection
- **Confetti**: Bursts on level-ups and perfect rounds
- **German Market Context**: Every question includes DACH-specific annotations

---

## 🎨 Design System

Warm, playful, Duolingo-meets-Notion aesthetic:
- **Light mode** with cream/off-white background
- **Warm pastels**: soft coral, muted teal, warm sand, lavender
- **Rounded everything**: cards, buttons, badges, progress bars
- **Playful micro-animations**: bounce, squish, shake, slide, confetti
- **Hand-drawn SVG icons** for categories, achievements, and ranks
- **Typography**: Nunito (body) + Baloo 2 (display headings)
- **Sticker-style** achievement badges

---

## 🛠 Customization

The entire app lives in `App.jsx`. Key sections to extend:

| Section | What it does |
|---------|-------------|
| `RESOURCE_LIBRARY` | Books, templates, and references |
| `QUESTIONS` | Question bank — follow the existing format to add more |
| `LEVELS` | XP thresholds and rank names |
| `ACHIEVEMENTS` | Unlockable stickers with conditions |
| `globalCSS` | All styles in one CSS string at the bottom |

### Adding a question:

```js
{
  category: "Your Category",    // Must match an existing category or add to CATEGORIES
  difficulty: 1,                // 1 = Basics, 2 = Intermediate, 3 = Expert
  type: "multiple_choice",      // or "true_false" or "scenario"
  question: "Your question?",
  options: ["A", "B", "C", "D"],
  correct: 2,                   // 0-indexed
  explanation: "Why C is correct...",
  germanContext: "German-specific notes..."  // optional but recommended
}
```

---

## Tech Stack
- React 18 (hooks only)
- Vite 5 for bundling
- Zero external UI libraries — pure CSS-in-JS
- Google Fonts: Nunito + Baloo 2
- Canvas API for confetti
- LocalStorage for progress persistence
